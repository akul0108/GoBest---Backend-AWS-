// Bike Model Read

const mongoose = require('mongoose');

let conn = null;

const uri = 'mongodb+srv://Akul:8VuKhSsQ8ZUxfi0g@goback-au6tb.mongodb.net/Bike?retryWrites=true&w=majority';

exports.handler = async function(event, context) {
  context.callbackWaitsForEmptyEventLoop = false;
  if (conn == null) {
    conn = await mongoose.createConnection(uri, {
      bufferCommands: false, 
      bufferMaxEntries: 0 
    });
    conn.model('model', new mongoose.Schema({ name: String }),'model');
  }

  const M = conn.model('model');

  const doc = await M.find();
  console.log(doc);

  return doc;
};