const mongoose = require('mongoose');

mongoose.Promise = global.Promise;

//Database Connection
mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true}, (err) => {
    if(!err)
        console.log('connected');
    else
        console.log('Not connected and error in MONGO'+ JSON.stringify(err, undefined, 2));
});

mongoose.set('useCreateIndex', true);

require('./user.model');
module.exports = mongoose;