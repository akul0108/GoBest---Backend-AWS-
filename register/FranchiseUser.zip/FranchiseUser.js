const mongoose = require('mongoose');
const Promise = require('bluebird');

// let conn = null;

const uri = 'mongodb+srv://Akul:8VuKhSsQ8ZUxfi0g@goback-au6tb.mongodb.net/User?retryWrites=true&w=majority';

const userSchema = new mongoose.Schema({
        username : {type: String},
        email : {type: String},
        fname : {type: String},
        lname : {type: String},
        gender : {type: String},
        phone : {type: Number},
        // Address Details
        address : {type: String},
        city : {type: String},
        district : {type: String},
        zip_code : {type: Number},
        state : {type: String},
        // Bank Details
        bank_name : {type: String},
        bank_ifsc : {type: String},
        account_holder_name : {type: String},
        account_number : {type: Number},
        // Company Details
        director : {type: String},
        branch_name : {type: String},
        branch_code : {type: Number},
        registration_number : {type: String},
        company_address : {type: String}
    });

module.exports.handler = function(event, context, callback) {
  context.callbackWaitsForEmptyEventLoop = false;

//   if (conn == null) {
//     conn = await mongoose.createConnection(uri, {
//       bufferCommands: false, 
//       bufferMaxEntries: 0 
//     });
//     const M = conn.model('users', new mongoose.Schema({ 
//         email: { type: String},
//         fname: { type: String},
//         lname: { type: String},
//         contact: { type: Number},
//         gender: { type: String},
//         address: { type: String}
//     }));
//   }
  
//   let MM = new users(user);
//   MM.save()
//   .then((data) => {
//       console.log(data);
//   }
//   .catch((err) => {
//       console.log(err);
//   }))

  

//   const doc = await M.save().then((err, doc) => {

//         if(!err)
//             return doc;
//         else
//         {
//             return err;
//         }
//     });

    mongoose.Promise = Promise;
    mongoose.connect(uri, {
        bufferCommands : false,
        bufferMaxEntries : 0,
        useNewUrlParser: true,
        useUnifiedTopology: true
        },
        (err) => {
            if(!err){
                // context.succeed('connected');
                
                var user = mongoose.model('User', userSchema);
                
                const data = JSON.parse(event.body);
                // const data = event;
    
                var User = new user();
                User.username = data.username;
                User.email = data.email;
                User.fname = data.fname;
                User.lname = data.lname;
                User.gender = data.gender;
                User.phone = data.phone;
                // Address Details
                User.address = data.address;
                User.city = data.city;
                User.district = data.district;
                User.zip_code = data.zip_code;
                User.state = data.state;
                // Bank Details
                User.bank_name = data.bank_name;
                User.bank_ifsc = data.bank_ifsc;
                User.account_holder_name = data.account_holder_name;
                User.account_number = data.account_number;
                // Company Details
                User.director = data.director;
                User.branch_name = data.branch_name;
                User.branch_code = data.branch_code;
                User.registration_number = data.registration_number;
                User.company_address = data.company_address;
                User.save().then(() => callback(null, {
                    statusCode: 200,
                    body : JSON.stringify(User),
                }))
                
                .catch(err => callback(err, {
                    statusCode: err.code,
                    body : err.message
                }))
            }
            else{
                context.none(JSON.stringify(err,undefined,2));
            }
        }
    )
}